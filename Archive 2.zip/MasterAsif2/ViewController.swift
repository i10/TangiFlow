//
//  ViewController.swift
//  MasterAsif2
//
//  Created by PPI on 11.12.18.
//  Copyright © 2018 RWTH Aachen University. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

