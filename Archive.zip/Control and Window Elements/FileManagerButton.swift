//
//  FileManagerButton.swift
//  MasterAsif2
//
//  Created by PPI on 07.05.19.
//  Copyright © 2019 RWTH Aachen University. All rights reserved.
//

import Foundation
import MultiTouchKitSwift

//extension MTKButton:ControlProtocol{
//    var value: String {
//        get {
//            return self.value
//        }
//        set {
//            self.value = newValue
//        }
//    }
//    
//    func getDict() -> JSON {
//        <#code#>
//    }
//    
//    
//}
