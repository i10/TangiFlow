//
//  KeyDictionary.swift
//  backendtest
//
//  Created by Asif Mayilli on 4/9/19.
//  Copyright © 2019 Test. All rights reserved.
//

import Foundation
class KeyDictionary{
    static var layout1 = [["q","w","e","r","t","y","u","i","o","p"],
                   ["a","s","d","f","g","h","j","k","l"],
                 ["Caps","z","x","c","v","b","n","m","Del"],
                        ["123","Space","Ret"]]
    
    static var layout2 = [["1","2","3","4","5","6","7","8","9","0"],
                   ["-","/",":",";","(",")","$","&","@","\""],
                   ["#+=",".",",","?","!","'","Del"],
                   ["ABC","Space","Ret"]]
    
    
    static var layout3 = [["[","]","{","}","#","%","^","*","+","="],
                          ["_","\\","|","~","<",">","$","&","@","\""],
                          ["123",".",",","?","!","'","Del"],
                          ["ABC","Space","Ret"]]
    
    static var numpad = ["7","8","9","4","5","6","1","2","3",".","0","←"]
    
   // print("|")

}
