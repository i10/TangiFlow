import Foundation
import SpriteKit
class Slider: SKNode {
    var min:Float = 0
    var max:Float = 100
    var step:Float = 1.0
    var bar:SKShapeNode = SKShapeNode(rectOf: CGSize(width: 200, height: 20))
    var button:SKShapeNode = SKShapeNode(rectOf: CGSize(width: 40, height: 40))
    var currentValueLabel:SKLabelNode?
    var currentValue = 50
    var totalSteps:Int{
        get{
            return Int(abs(max-min)/step)
        }
    }
    
    override init() {
        super.init()
        self.drawBar()
        self.drawSliderButton()
        self.drawSideLabels()
        
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func drawBar(){
        self.bar.fillColor = SKColor.gray
        self.addChild(self.bar)
    }
    
    func drawSliderButton(){
        self.currentValueLabel = SKLabelNode(text: String(self.currentValue))
        self.currentValueLabel!.position = CGPoint(x: 0, y: 30)
        self.button.position = CGPoint(x: -80, y: 0)
        self.button.addChild(self.currentValueLabel!)
        self.button.fillColor = SKColor.black
        self.bar.addChild(self.button)
        self.button.name = "sliderButton"
    }
    
    func drawSideLabels(){
        let leftLabel:SKLabelNode = SKLabelNode(text: String(self.min))
        let rightLabel:SKLabelNode = SKLabelNode(text: String(self.max))
        leftLabel.position = CGPoint(x: -100 - leftLabel.frame.width, y: -13)
        rightLabel.position = CGPoint(x:100 + rightLabel.frame.width/1.5,y:-13)
        self.addChild(leftLabel)
        self.addChild(rightLabel)
    }
    
    func countValue(){
        var distance = abs(CGFloat(max-min))
        var stepPix = CGFloat(160.0/distance)
        print(button.position.x)
        print(stepPix)
        print("=============================")
        var value = abs(CGFloat(CGFloat(min)-button.position.x))/stepPix
        self.currentValueLabel!.text = "\(value)"
        
    }
}

