//
//  Center.swift
//  Test1
//
//  Created by Asif Mayilli on 11/16/18.
//  Copyright © 2018 Test. All rights reserved.
//

import Foundation
import SpriteKit
class Center:SKShapeNode{

//    convenience init(circleOfRadius radius:CGFloat ) {
//        super.init(circleOfRadius: <#T##CGFloat#>)
//        
//    }
//    
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
}
