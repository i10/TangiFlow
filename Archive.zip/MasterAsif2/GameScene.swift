//
//  GameScene.swift
//  Test1
//
//  Created by Asif Mayilli on 10/30/18.
//  Copyright © 2018 Test. All rights reserved.
//

import SpriteKit

import MultiTouchKitSwift
class GameScene: MTKScene {
    var tangibleToNode:[String:Node] = [:]
    var drawLineMode = false
    var startArc:Arc?
    var endArc:Arc?
    var currentDrawnEdge:Edge?
    var graph:Graph?
    var selectedArc:Arc?
    var selectedNode:Node?
    var time = 0.0
    var start:Date?
    var end:Date?
    var moveStart:Date?
    var moveEnd:Date?
    var deltaMoveT = 1.0
    var deltaT = 0.5
    override func setupScene() {
        graph = Graph(scene: self)
//        let node = Node(position: CGPoint(x: 1050.0, y: 1050.0))
//        let node1 = Node(position: CGPoint(x: 750.0, y: 850.0))
//        let node2 = Node(position: CGPoint(x: 920.0, y: 120.0))
//        let node3 = Node(position: CGPoint(x: 2069.0, y: 1035))
//        self.graph?.addNode(node: node)
//        self.graph?.addNode(node: node1)
//        self.graph?.addNode(node: node2)
//        self.graph?.addNode(node: node3)
        MTKHub.sharedHub.traceDelegate = self
        MTKUtils.tangibleLogging
//        MTKUtils.traceVisualization = true
//        MTKUtils.showTangibleInfo = true
        
    }
    
    func preProcessTraceSet(traceSet: Set<MTKTrace>, node: SKNode, timestamp: TimeInterval) -> Set<MTKTrace> {
            var locDelta = 20.0
        
            for passiveTangible in self.passiveTangibles {
                print("===================tangible==================")
                print(passiveTangible.state)
                print(passiveTangible.trackingState)
                print("==============================================")
                if(
                    passiveTangible.state == .initializedButLostTracking ||
                    passiveTangible.trackingState == MTKUtils.MTKTangibleTrackingState.recognizedAndRecoveringMissingTraces){
                    self.start = Date()
                    //return traceSet
                    print("i worked 1")
                    
                } else if (passiveTangible.state == .initializedAndRecognized ||
                    passiveTangible.trackingState == MTKUtils.MTKTangibleTrackingState.fullyRecognized) {
                    //var locDelta = 20.0
                    print("i wroked 2")
                    if let start = self.start{
                        self.end = Date()
                        locDelta = self.end!.timeIntervalSince(start).rounded(.down)
                    }

                    if ((locDelta)>self.deltaT){
                            self.graph?.touchDown(atPoint: passiveTangible.position)
                            
                            if tangibleToNode[passiveTangible.identifier] == nil{
                                let node = Node(position: passiveTangible.position)
                                self.tangibleToNode[passiveTangible.identifier] = node
                                self.graph?.addNode(node: node)
                                
                            }else if(passiveTangible.currentA?.state == MTKUtils.MTKTraceState.movingTrace ||
                                    passiveTangible.currentB?.state == MTKUtils.MTKTraceState.movingTrace  ||
                                    passiveTangible.currentC?.state == MTKUtils.MTKTraceState.movingTrace) {
                                if self.moveStart == nil {
                                    self.moveStart = Date()
                                    
                                }
                                self.graph?.touchDown(atPoint: passiveTangible.position)
                                
                                self.graph?.touchMoved(toPoint: passiveTangible.position)
                                print("move")
                                if self.moveStart != nil {
                                    self.moveEnd = Date()
                                    
                                }
                                
            
                            }else if(passiveTangible.currentA?.state == MTKUtils.MTKTraceState.endingTrace ||
                                passiveTangible.currentB?.state == MTKUtils.MTKTraceState.endingTrace  ||
                                passiveTangible.currentC?.state == MTKUtils.MTKTraceState.endingTrace){
                                
                                if let start = self.moveStart{
                                    
                                }
                                
                            }
                            
                            else {
                                print("I work now")
                                self.graph?.touchUp(atPoint: passiveTangible.position)
                            }
                    } else{
                        self.start = nil
                        self.end = nil
                    }

                }else if(passiveTangible.trackingState == MTKUtils.MTKTangibleTrackingState.notRecognized){
                    print("i worked 3")
                    if let start = self.moveStart, let end = self.moveEnd{
                    var delta = end.timeIntervalSince(start)
                    if(delta>self.deltaMoveT){
                        self.tangibleToNode[passiveTangible.identifier]?.removeFromParent()
                        print("up")
                        }
                        
                    }
                }
                
            }

        return traceSet
    }

    override func update(_ currentTime: TimeInterval) {
        super.update(currentTime)
        
    }
}


