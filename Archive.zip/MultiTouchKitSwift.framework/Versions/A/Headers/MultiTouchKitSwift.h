//
//  MultiTouchKitSwift.h
//  MultiTouchKitSwift
//
//  Created by David Asselborn on 24.04.17.
//  Copyright © 2017 i10. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import <SpriteKit/SpriteKit.h>
#import "CocoaAsyncSocket.h"

//! Project version number for MultiTouchKitSwift.
FOUNDATION_EXPORT double MultiTouchKitSwiftVersionNumber;

//! Project version string for MultiTouchKitSwift.
FOUNDATION_EXPORT const unsigned char MultiTouchKitSwiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MultiTouchKitSwift/PublicHeader.h>
